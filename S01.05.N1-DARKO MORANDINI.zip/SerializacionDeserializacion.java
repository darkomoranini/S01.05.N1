import java.io.File;
import java.io.Serializable;

@SuppressWarnings("serial")
public class SerializacionDeserializacion implements Serializable {

	private File fichero;
	
	public SerializacionDeserializacion(File fichero) {
		this.fichero=fichero;
	}

	public File getFichero() {
		return fichero;
	}

	public void setFichero(File fichero) {
		this.fichero = fichero;
	}

	
}
