import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;

public class App1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ArchivosFicheros ejemplo=new ArchivosFicheros();
		ejemplo.leerFichero();
		ejemplo.ordenaLista();
		ejemplo.imprimeLista();
		
		BinarySearchTree<String> arbol = new BinarySearchTree<>();
		
		File fichero=new File("/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/Countries.txt");
		
		try {
			ejemplo.leerFicheroArbol(arbol, fichero);		
		}catch(IOException e) {
			System.out.println("Archivo no encontrado");
		}
		
		arbol.mostrar(arbol.getRoot());
		
		File fichero1 = new File("/Users/darkomorandini/Desktop/eclipse/ARCHIVOS EXT/Nuevo.txt");
		
		try {
		rellenaFichero(ejemplo, fichero1);
		}catch(IOException e) {
			System.out.println("Archivo no encontrado");		
		}
		
		System.out.println(fichero1.canRead());
	
		SerializacionDeserializacion ser = new SerializacionDeserializacion(fichero1);
		
		File fileSer=null;
		
		try {
		fileSer = serializacion(ser);
		}catch(IOException e) {
			System.out.println("Archivo no encontrado");
		}
		
		try {
		deserializacion(fileSer);
		}catch(IOException e) {
			System.out.println("Archivo no encontrado");
		}catch(ClassNotFoundException i) {
			System.out.println("Clase desconocida o incompatible");
		}
	}

	public static void rellenaFichero(ArchivosFicheros ejemplo, File fichero) throws IOException{
		
		try {
			ejemplo.rellenaFichero(fichero);
		} catch (IOException e) {
			System.out.println("No se encuentra archivo de destino");
		}
	}
	
	public static File serializacion(SerializacionDeserializacion ser) throws IOException {
	  
		String fileName = "Nuevo.txt";
	    try (FileOutputStream file = new FileOutputStream(fileName);
	         ObjectOutputStream out = new ObjectOutputStream(file)) { 
	        
	    	// serializacion
	        out.writeObject(ser);	          	
	        System.out.println("Object serializado");
	  
	        return new File(fileName);
	        
	    } catch(IOException ex) {
	        System.out.println("IOException atrapada");
	    }
	    	return null;
	}
	
	public static SerializacionDeserializacion deserializacion(File fichero) throws IOException, ClassNotFoundException {
		
		 try (FileInputStream file = new FileInputStream(fichero);
		         ObjectInputStream ois = new ObjectInputStream(file)) {
		        
		        // deserealizacion
			 SerializacionDeserializacion ser = (SerializacionDeserializacion) ois.readObject();
		          
		     System.out.println("Objeto deserealizado");
		  
		     return ser;
		     
		    } catch(IOException e) {
		        System.out.println("IOException atrapada");
		    } catch(ClassNotFoundException e) {
		        System.out.println("ClassNotFoundException atrapada");
		    }		 	
		 	return null;
	}
	
}
